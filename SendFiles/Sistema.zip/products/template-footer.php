            <footer>
                <section>
                    Desenvolvido por Paulo Sette
                </section>
            </footer>
        </div>
    </body>
</html>